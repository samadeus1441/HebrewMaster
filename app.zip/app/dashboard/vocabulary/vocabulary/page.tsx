import { createClient } from '@supabase/supabase-js';

// Force this page to always fetch fresh data
export const dynamic = 'force-dynamic';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export default async function VocabularyPage() {
  // 1. Fetch data from Supabase
  const { data: words } = await supabase
    .from('vocabulary')
    .select('*')
    .order('created_at', { ascending: false });

  return (
    <div className="p-8 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">My Vocabulary</h1>
        <span className="bg-indigo-100 text-indigo-800 px-3 py-1 rounded-full text-sm font-medium">
          {words?.length || 0} Words
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {words?.map((word) => (
          <div key={word.id} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-1">{word.hebrew}</h2>
                <p className="text-gray-400 font-mono text-sm">{word.transliteration}</p>
              </div>
              <span className="text-xs font-bold text-gray-300 uppercase">{word.part_of_speech || 'word'}</span>
            </div>
            
            <div className="mt-4 pt-4 border-t border-gray-50">
              <p className="text-lg font-medium text-indigo-700">{word.meaning_en}</p>
              {word.meaning_fr && (
                <p className="text-sm text-gray-400 mt-1">{word.meaning_fr}</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}