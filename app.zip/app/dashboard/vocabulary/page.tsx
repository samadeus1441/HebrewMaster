import { supabase } from '@/lib/supabase'
import { Suspense } from 'react'
import VocabCard from '@/components/VocabCard'

export default async function VocabularyPage() {
  return (
    <div className="p-8">
      <div className="max-w-7xl mx-auto space-y-12">
        <div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Vocabulary</h1>
          <p className="text-gray-600">Explore Hebrew words organized by morphological structure</p>
        </div>
        
        <Suspense fallback={<VocabularyLoadingSkeleton />}>
          <VocabularySections />
        </Suspense>
      </div>
    </div>
  )
}

async function VocabularySections() {
  // Fetch vocabulary and roots separately, then merge
  const { data: vocabulary, error: vocabError } = await supabase
    .from('vocabulary')
    .select('*')
    .order('created_at', { ascending: false })

  if (vocabError) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6">
        <p className="text-red-800">Error loading vocabulary: {vocabError.message}</p>
      </div>
    )
  }

  // Fetch all roots to create a lookup map
  const { data: roots } = await supabase
    .from('roots')
    .select('id, root_letters')

  // Create a map of root_id -> root_letters
  const rootsMap = new Map(
    roots?.map((root) => [root.id, { root_letters: root.root_letters }]) || []
  )

  // Merge vocabulary with root data
  const vocabularyWithRoots = vocabulary?.map((word) => ({
    ...word,
    root: word.root_id ? rootsMap.get(word.root_id) || null : null,
  })) || []

  const error = vocabError

  if (!vocabularyWithRoots || vocabularyWithRoots.length === 0) {
    return (
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-12 text-center">
        <p className="text-gray-600 text-lg">No vocabulary words found. Seed the database first.</p>
      </div>
    )
  }

  // Separate into Core Roots (with roots) and Daily Vocabulary (without roots)
  const coreRoots = vocabularyWithRoots.filter((word) => word.root_id !== null && word.root)
  const dailyVocabulary = vocabularyWithRoots.filter((word) => word.root_id === null || !word.root)

  return (
    <div className="space-y-12">
      {/* Core Roots Section */}
      {coreRoots.length > 0 && (
        <section>
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Core Roots</h2>
            <p className="text-gray-600">Words derived from fundamental Hebrew roots</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {coreRoots.map((word) => (
              <VocabCard key={word.id} word={word} />
            ))}
          </div>
        </section>
      )}

      {/* Daily Vocabulary Section */}
      {dailyVocabulary.length > 0 && (
        <section>
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Daily Vocabulary</h2>
            <p className="text-gray-600">Essential words for everyday communication</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {dailyVocabulary.map((word) => (
              <VocabCard key={word.id} word={word} />
            ))}
          </div>
        </section>
      )}
    </div>
  )
}

function VocabularyLoadingSkeleton() {
  return (
    <div className="space-y-12">
      {/* Core Roots Skeleton */}
      <section>
        <div className="mb-6">
          <div className="h-8 bg-gray-200 rounded w-48 mb-2 animate-pulse"></div>
          <div className="h-4 bg-gray-200 rounded w-64 animate-pulse"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="bg-white rounded-xl border border-gray-200 p-8 animate-pulse"
            >
              <div className="h-16 bg-gray-200 rounded mb-4"></div>
              <div className="h-4 bg-gray-200 rounded mb-3 w-3/4 mx-auto"></div>
              <div className="h-5 bg-gray-200 rounded w-1/2 mx-auto"></div>
            </div>
          ))}
        </div>
      </section>

      {/* Daily Vocabulary Skeleton */}
      <section>
        <div className="mb-6">
          <div className="h-8 bg-gray-200 rounded w-48 mb-2 animate-pulse"></div>
          <div className="h-4 bg-gray-200 rounded w-64 animate-pulse"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="bg-white rounded-xl border border-gray-200 p-8 animate-pulse"
            >
              <div className="h-16 bg-gray-200 rounded mb-4"></div>
              <div className="h-4 bg-gray-200 rounded mb-3 w-3/4 mx-auto"></div>
              <div className="h-5 bg-gray-200 rounded w-1/2 mx-auto"></div>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
