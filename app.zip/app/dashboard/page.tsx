import Link from 'next/link';

export default function Dashboard() {
  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Welcome Back, Student</h1>
          <p className="text-gray-500 mt-1">Ready to continue your Hebrew journey?</p>
        </div>
        <div className="text-right hidden sm:block">
          <p className="text-sm text-gray-400">Current Level</p>
          <p className="font-bold text-indigo-600">Aleph (A1)</p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <p className="text-gray-500 text-sm font-medium uppercase">Total XP</p>
          <p className="text-4xl font-bold text-gray-900 mt-2">1,840</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <p className="text-gray-500 text-sm font-medium uppercase">Current Streak</p>
          <p className="text-4xl font-bold text-orange-500 mt-2">7 Days</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <p className="text-gray-500 text-sm font-medium uppercase">Words Learned</p>
          <p className="text-4xl font-bold text-indigo-600 mt-2">247</p>
        </div>
      </div>

      {/* Action Card */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Next Lesson: Binyan Pa'al</h2>
          <p className="text-gray-500 mt-2">Learn the fundamental verb patterns of Hebrew.</p>
        </div>
        <Link 
          href="/dashboard/vocabulary" 
          className="px-6 py-3 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200"
        >
          Start Review
        </Link>
      </div>
    </div>
  );
}