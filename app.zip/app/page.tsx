import AlephBetGrid from '@/components/AlephBetGrid'
import Link from 'next/link'

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 md:py-32">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6 leading-tight">
            <span dir="ltr">Master Hebrew Logic,</span>
            <br />
            <span dir="ltr" className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Not Just Words
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-600 mb-12 max-w-2xl mx-auto leading-relaxed">
            Experience evidence-based learning with the Free Spaced Repetition System. 
            Build fluency through morphology, not memorization.
          </p>
          
          <Link 
            href="/dashboard"
            className="inline-block px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-lg font-semibold rounded-xl shadow-lg hover:shadow-2xl hover:scale-105 transition-all duration-300 transform"
          >
            Start Learning
          </Link>
        </div>
      </section>

      {/* Aleph-Bet Interactive Module */}
      <section className="container mx-auto px-4 py-12 md:py-20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 mb-4">
            Explore the Aleph-Bet
          </h2>
          <p className="text-center text-gray-600 mb-12 text-lg">
            Hover over each letter to see its cursive form
          </p>
          
          <div className="flex justify-center">
            <AlephBetGrid />
          </div>
        </div>
      </section>

      {/* Footer Spacing */}
      <div className="h-20"></div>
    </main>
  )
}
