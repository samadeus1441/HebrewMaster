'use client';

import { createClient } from '@supabase/supabase-js';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

// --- FSRS ALGORITHM (Simplified) ---
const calculateNextReview = (rating: string) => {
  switch (rating) {
    case 'again': return '1m'; // 1 minute
    case 'hard': return '2d';  // 2 days
    case 'good': return '4d';  // 4 days
    case 'easy': return '7d';  // 7 days
    default: return '1d';
  }
};

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export default function StudyPage() {
  const [words, setWords] = useState<any[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [loading, setLoading] = useState(true);
  const [sessionComplete, setSessionComplete] = useState(false);
  
  // הוספתי מצב לאודיו כדי שנדע מתי הוא טוען
  const [audioStatus, setAudioStatus] = useState<'idle' | 'loading' | 'playing'>('idle');

  // 1. FETCH SESSION DATA
  useEffect(() => {
    async function loadSession() {
      const { data } = await supabase
        .from('vocabulary')
        .select('*')
        .limit(10);

      if (data && data.length > 0) {
        setWords(data);
      }
      setLoading(false);
    }
    loadSession();
  }, []);

  // 2. AUDIO ENGINE (UPDATED TO USE SERVER/OPENAI)
  const playAudio = async (text: string) => {
    if (audioStatus === 'playing') return; // מונע כפילויות
    
    try {
      setAudioStatus('loading');
      
      // קריאה לשרת החדש שבנינו (OpenAI)
      const response = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });

      if (!response.ok) throw new Error('Audio fetch failed');

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      
      audio.onended = () => setAudioStatus('idle');
      await audio.play();
      setAudioStatus('playing');

    } catch (error) {
      console.error("Audio Error:", error);
      setAudioStatus('idle');
    }
  };

  // Auto-play when a new card appears
  useEffect(() => {
    if (!loading && words[currentIndex] && !isFlipped) {
      playAudio(words[currentIndex].hebrew);
    }
  }, [currentIndex, loading, words, isFlipped]);

  const handleRating = (rating: string) => {
    console.log(`User rated card: ${rating}`);
    
    // Move to next card
    if (currentIndex < words.length - 1) {
      setIsFlipped(false);
      setCurrentIndex(prev => prev + 1);
    } else {
      setSessionComplete(true);
    }
  };

  if (loading) return <div className="flex h-screen items-center justify-center font-bold text-xl">Loading Engine...</div>;
  
  if (words.length === 0) return (
    <div className="flex flex-col items-center justify-center h-[80vh] space-y-4">
      <h2 className="text-2xl font-bold text-red-500">No Cards Found</h2>
      <p className="text-gray-600">Please run the seed script first.</p>
    </div>
  );

  if (sessionComplete) return (
    <div className="flex flex-col items-center justify-center h-[80vh] space-y-6 animate-in fade-in zoom-in duration-500">
      <div className="text-8xl">🏆</div>
      <h1 className="text-4xl font-bold text-gray-900">Session Complete!</h1>
      <p className="text-xl text-gray-500">You just strengthened {words.length} neural pathways.</p>
      <button 
        onClick={() => window.location.reload()}
        className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 shadow-lg hover:shadow-indigo-200 transition-all"
      >
        Start Another Session
      </button>
    </div>
  );

  const currentWord = words[currentIndex];

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-8 min-h-screen flex flex-col justify-center">
      
      {/* Progress Bar */}
      <div className="w-full bg-gray-200 rounded-full h-2.5 mb-8">
        <div 
          className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500" 
          style={{ width: `${((currentIndex) / words.length) * 100}%` }}
        ></div>
      </div>

      {/* THE FLASHCARD INTERFACE */}
      <div className="relative h-96 perspective-1000">
        <AnimatePresence mode='wait'>
          {!isFlipped ? (
            // FRONT OF CARD (Question)
            <motion.div 
              key="front"
              initial={{ rotateY: 90, opacity: 0 }}
              animate={{ rotateY: 0, opacity: 1 }}
              exit={{ rotateY: -90, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="absolute inset-0 bg-white rounded-3xl shadow-xl border border-gray-100 flex flex-col items-center justify-center cursor-pointer hover:shadow-2xl transition-all"
              onClick={() => setIsFlipped(true)}
            >
              <span className="text-gray-400 text-xs font-bold uppercase tracking-widest mb-6">Tap to Reveal</span>
              <h1 className="text-8xl font-bold text-gray-900 mb-8 font-serif">{currentWord.hebrew}</h1>
              
              <button 
                onClick={(e) => { e.stopPropagation(); playAudio(currentWord.hebrew); }}
                className={`p-4 rounded-full ${audioStatus === 'loading' ? 'bg-indigo-100 animate-pulse' : 'bg-indigo-50'} text-indigo-600 hover:bg-indigo-100 hover:scale-110 transition-all`}
              >
                {audioStatus === 'loading' ? "⏳" : (
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>
                )}
              </button>
            </motion.div>
          ) : (
            // BACK OF CARD (Answer)
            <motion.div 
              key="back"
              initial={{ rotateY: 90, opacity: 0 }}
              animate={{ rotateY: 0, opacity: 1 }}
              exit={{ rotateY: -90, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="absolute inset-0 bg-indigo-50 rounded-3xl shadow-xl border border-indigo-100 flex flex-col items-center justify-center p-8 text-center"
            >
              <h2 className="text-5xl font-bold text-indigo-900 mb-2 font-serif">{currentWord.hebrew}</h2>
              <p className="text-xl text-gray-500 font-mono mb-6">{currentWord.transliteration}</p>
              
              <div className="bg-white px-8 py-4 rounded-xl shadow-sm mb-8 w-full">
                <p className="text-3xl font-bold text-gray-800">{currentWord.meaning_en}</p>
                <p className="text-sm text-gray-400 mt-1">{currentWord.meaning_fr}</p>
              </div>

              {/* FSRS RATINGS */}
              <div className="grid grid-cols-4 gap-3 w-full mt-auto">
                <button onClick={() => handleRating('again')} className="py-3 px-2 rounded-xl bg-red-100 text-red-700 font-bold hover:bg-red-200 transition-colors flex flex-col items-center">
                  <span className="text-sm">Again</span>
                  <span className="text-[10px] font-normal opacity-75">1m</span>
                </button>
                <button onClick={() => handleRating('hard')} className="py-3 px-2 rounded-xl bg-orange-100 text-orange-700 font-bold hover:bg-orange-200 transition-colors flex flex-col items-center">
                  <span className="text-sm">Hard</span>
                  <span className="text-[10px] font-normal opacity-75">2d</span>
                </button>
                <button onClick={() => handleRating('good')} className="py-3 px-2 rounded-xl bg-green-100 text-green-700 font-bold hover:bg-green-200 transition-colors flex flex-col items-center">
                  <span className="text-sm">Good</span>
                  <span className="text-[10px] font-normal opacity-75">4d</span>
                </button>
                <button onClick={() => handleRating('easy')} className="py-3 px-2 rounded-xl bg-blue-100 text-blue-700 font-bold hover:bg-blue-200 transition-colors flex flex-col items-center">
                  <span className="text-sm">Easy</span>
                  <span className="text-[10px] font-normal opacity-75">7d</span>
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}